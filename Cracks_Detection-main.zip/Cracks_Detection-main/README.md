# Cracks_Detection

#### Concrete surface cracks are major defect in Civil structures. 
Building Inspection which is done for the evaluation of rigidity and tensile strength of the building. 
Crack detection plays a major role in the building inspection, finding the cracks and determining the building health.

#### Dataset Link:
[Dataset Link](https://www.kaggle.com/arunrk7/surface-crack-detection)

#### LinkedIn:
[LinkedIn Profile](https://www.linkedin.com/in/mlagoor/)

